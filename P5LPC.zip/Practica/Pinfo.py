from bs4 import BeautifulSoup as bs
from openpyxl.reader.excel import load_workbook
import requests
import re
import time

pathExcel = "/home/runner/P5LPC/Practica/InfoBanda.xlsx"

libro = load_workbook(pathExcel)
hoja = libro.active
w = 2

def info():
    informacion={
        "Fundacion": "",
        "Integrantes": "",
        "Sencillos": ""
    }

    pFundacion = re.compile("Fundado en \d de \d+")
    pInteg = re.compile("esta formado por \d+")
    pSenci = re.compile("En 2008 los sencillos \d+\s\d+")

    print("Realizando busqueda de informacion...")
    time.sleep(3)
    url = "https://es.wikipedia.org/wiki/Kings_of_Leon"
    pagina = requests.get(url)
    if pagina.status_code != 200:
        print("Pagina de información no disponible. Intentelo mas tarde.")
    else: 
        soup = bs(pagina.content, "html.parser")
        print("Informacion encontrada con exito. Añadiendo a hoja de trabajo...")
    info = soup.find_all("p")
    if info != None:
        for parrafos in info:
            match1 = re.search(pFundacion, parrafos.getText()) 
            if match1:
                coinc = re.search(pFundacion, parrafos.getText()).group()
                informacion["Fundacion"] = re.sub("Fundado en ", "", coinc)
            match2 = re.search(pFundacion, parrafos.getText()) 
            if match2:
                coinc = re.search(pInteg, parrafos.getText()).group()
                informacion["Integrantes"] = re.sub("esta formado por ", "", coinc)
            match3 = re.search(pSenci, parrafos.getText()) 
            if match3:
                coinc = re.search(pSenci, parrafos.getText()).group()
                coinc = coinc.replace("\xa0", " ")
                informacion["Sencillos"] = re.sub("En 2008 los sencillos ", "", coinc)

    hoja['B2'] = informacion["Fundacion"]
    hoja['C2'] = informacion["Integrantes"]
    hoja['D2'] = informacion["Sencillos"]

    libro.save(pathExcel)

    print("Listo!")
