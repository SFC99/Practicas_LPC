from openpyxl.reader.excel import load_workbook
import requests
import re
from bs4 import BeautifulSoup as bs
from urllib.parse import urljoin

def noticias():
        archivoLista=[]
#Se abre el archivo y se obtienen los links en una lista
        pathArchivo = "/home/runner/P5LPC/Practica/Noticias.txt"
        archivo = open(pathArchivo, "r+").readlines()
        for linea in archivo:
            archivoLista.append(linea.strip())

#Se carga la hoja de trabajo
        pathExcel = "/home/runner/P5LPC/Practica/InfoBanda.xlsx"
        libro = load_workbook(pathExcel)
        hoja=libro.active
        w = 2

#Se busca en los links preestablecidos la noticia mas reciente y se escribe a la hoja de trabajo
        for i in archivoLista:
                print("Realizando busqueda en pagina: ", i)
                j = 1
                control = 0
                while control == 0:
                    url = i + str(j)
                    pagina = requests.get(url)
                    if pagina.status_code != 200:
                        print ("Pagina no encontrada.Comenzando busqueda en siguiente link.")
                        break
                    else:
                        soup=bs(pagina.content, "html.parser")
                    info = soup.find('a', string=re.compile('kings of leon',re.IGNORECASE))
                    if info != None:
                        href = info.get('href')
                        absLink = urljoin(url,href)
                        hoja[f'E{w}'] = absLink
                        w += 1
                        control += 1
                    else:
                        j += 1
        libro.save(pathExcel)
                

