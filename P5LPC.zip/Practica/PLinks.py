path = "/home/runner/P5LPC/Practica/Noticias.txt"
def AgregarLink ():
        fo = open (path+"/Noticias.txt","a")
        url = (input("\nNuevo link: "))
        fo.write(url+"\n")
        fo.close()
def EliminarLink():
        num = 1
        fo = open (path+"/Noticias.txt","r+")
        arclist = fo.readlines()
        fo.close()
        for items in arclist:
                print(num, items)
                num += 1
        opcion = int(input("Link a eliminar: "))
        opcion -= 1
        del arclist[opcion]
        fo = open (path+"/Noticias.txt", "w")
        for items in arclist:
                fo.write(items)
        fo.close()
