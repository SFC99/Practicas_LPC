import os
import requests

# Se define el nombre de la carpeta o directorio a crear

def Carpeta():
    directorio = "/home/runner/P5LPC/Practica/fotitos"
    try:
        os.mkdir(directorio)
    except OSError:
        print("La creación del directorio %s falló" % directorio)
    else:
        print("Se ha creado el directorio: %s " % directorio)
    
