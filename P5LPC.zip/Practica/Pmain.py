import os
import PLinks
import Pinfo
import Psoup
import PCarpeta
from pyowm.owm import OWM
from openpyxl.reader.excel import load_workbook
import requests

path = "/home/runner/P5LPC/Practica"
archivos = os.listdir(path)
print (archivos)
##SE IMPRIMEN LOS ARCHIVOS TXT ENCONTRADOS##
for i in archivos:
        if ".txt" in i:
                x = path + "/" + i
                print('\nArchivos encontrados:', x)

opcion = (input("\n¿Qué deseas hacer?\n1.Agregar link  2.Eliminar link  3.Informacion revelante 4.Buscar noticias relacionadas\n 5.Crear carpeta de imagenes 6.Descargar imagenes 7.Pronostico\n"))
if opcion == '1':
        PLinks.AgregarLink()
if opcion == '2':
        PLinks.EliminarLink()
if opcion == '3':
        Pinfo.info()
if opcion == '4':
        Psoup.noticias()
if opcion == '5':
        PCarpeta.Carpeta()
if opcion == '6':
          response = requests.get("hhttps://images.clarin.com/2021/03/30/tras-un-lustro-kings-of___fWdSCPgqG_1256x620__2.jpg#1617660225063")
          file = open("/home/runner/P5LPC/Practica/fotitos"+"/imagen1.jpg", "wb")
          file.write(response.content)
          file.close()
          response = requests.get("https://images.foxtv.com/static.foxla.com/www.foxla.com/content/uploads/2021/09/764/432/GettyImages-1315284882.jpg?ve=1&tl=1")
          file = open("/home/runner/P5LPC/Practica/fotitos"+"/imagen2.jpg", "wb")
          file.write(response.content)
          file.close()
          response = requests.get("https://www.rockzonemag.com/wp-content/uploads/2021/01/kings-of-leon-foto-2021-1021x523.gif")
          file = open("/home/runner/P5LPC/Practica/fotitos"+"/imagen3.jpg", "wb")
          file.write(response.content)
          file.close()
          response = requests.get("https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Kings_of_leon.JPG/250px-Kings_of_leon.JPGg")
          file = open("/home/runner/P5LPC/Practica/fotitos"+"/imagen4.jpg", "wb")
          file.write(response.content)
          file.close()
          response = requests.get("https://rockfm-cdnmed.agilecontent.com/resources/jpg/0/5/1628164758350.jpg")
          file = open("/home/runner/P5LPC/Practica/fotitos"+"/imagen5.jpg", "wb")
          file.write(response.content)
          file.close()
          
if opcion == '7':
        API_KEY = "83ed68fa56986a9407a35db3c8645e4d"
        owm = OWM(API_KEY)
        mgr = owm.weather_manager()
        one_call = mgr.one_call(lat=25.67507,lon=-100.31847)

        pathExcel = "/home/runner/P5LPC/Practica/InfoBanda.xlsx"
        libro = load_workbook(pathExcel)
        hoja = libro.active

        control = 0

        while control == 0:
            print("¿Que desea hacer?\n1.Revisar estado del tiempo.\n2.Salir\n\nIngrese la opcion: ")
            opc = int(input())
            w = 8
            if opc == 1:
                print("Revision de estado del tiempo")
                ##Preguntamos el numero de dias, maximo 7 (Una semana)
                ##Donde esta la variable [day] es donde van los dias
                tomorrow = one_call.forecast_daily[day].temperature('celsius').get('feels_like_day', None) 
                print ('La temperatura de Monterrey en ',day,'dias sera: ',tomorrow)
                tup = ('La temperatura de Monterrey en ',day,'dias sera: ',tomorrow)
                var = list(tup)
                completo = ''.join([str(elem) for elem in tup])
                print("\n Añadiendo informacion a hoja de trabajo...")
                hoja[f'B{w}']= completo
                w += 1
            break
        libro.save(pathExcel)
        print("Finalizando... Listo.")